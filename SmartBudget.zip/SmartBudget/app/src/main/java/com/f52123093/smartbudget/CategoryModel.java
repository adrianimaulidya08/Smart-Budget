package com.f52123093.smartbudget;

public class CategoryModel {
    private int icon;
    private String namaKategori;

    public CategoryModel(int icon, String namaKategori) {
        this.icon = icon;
        this.namaKategori = namaKategori;
    }

    public int getIcon() {
        return icon;
    }

    public String getNamaKategori() {
        return namaKategori;
    }
}


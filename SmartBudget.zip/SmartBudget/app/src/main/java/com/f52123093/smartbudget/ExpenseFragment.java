package com.f52123093.smartbudget;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ExpenseFragment extends Fragment {

    private GridView gridKategori;
    private EditText edtNota, edtJumlah;
    private ArrayList<CategoryModel> kategoriList;
    private CategoryAdapter adapter;
    private String selectedKategori = "";

    public ExpenseFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        gridKategori = view.findViewById(R.id.gridKategori);
        edtNota = view.findViewById(R.id.edtNota);
        edtJumlah = view.findViewById(R.id.edtJumlah);

        kategoriList = new ArrayList<>();
        kategoriList.add(new CategoryModel(R.drawable.img1, "Makanan"));
        kategoriList.add(new CategoryModel(R.drawable.img2, "Kendaraan"));
        kategoriList.add(new CategoryModel(R.drawable.img13, "Lainnya"));

        adapter = new CategoryAdapter(getContext(), kategoriList);
        gridKategori.setAdapter(adapter);

        gridKategori.setOnItemClickListener((AdapterView<?> parent, View v, int position, long id) -> {
            CategoryModel selected = kategoriList.get(position);

            selectedKategori = selected.getNamaKategori();

            Toast.makeText(getContext(), "Kategori: " + selectedKategori, Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.btnSimpan).setOnClickListener(v -> {
            String nota = edtNota.getText().toString();
            String jumlahStr = edtJumlah.getText().toString();

            if (nota.isEmpty() || jumlahStr.isEmpty() || selectedKategori.isEmpty()) {
                Toast.makeText(getContext(), "Lengkapi data & pilih kategori!", Toast.LENGTH_SHORT).show();
            } else {
                double jumlah = Double.parseDouble(jumlahStr);
                DatabaseHelper dbHelper = new DatabaseHelper(getContext());

                dbHelper.tambahTransaksi(selectedKategori, nota, jumlah, "pengeluaran");

                Toast.makeText(getContext(), "Pengeluaran disimpan", Toast.LENGTH_SHORT).show();
                edtNota.setText("");
                edtJumlah.setText("");
                selectedKategori = "";
            }
        });

        return view;
    }
}
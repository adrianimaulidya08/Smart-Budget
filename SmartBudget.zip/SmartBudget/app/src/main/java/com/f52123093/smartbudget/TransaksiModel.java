package com.f52123093.smartbudget;

public class TransaksiModel {
    private String kategori;
    private String catatan;
    private double jumlah;
    private boolean isPengeluaran;

    public TransaksiModel(String kategori, String catatan, double jumlah, boolean isPengeluaran) {
        this.kategori = kategori;
        this.catatan = catatan;
        this.jumlah = jumlah;
        this.isPengeluaran = isPengeluaran;
    }

    public String getKategori() { return kategori; }
    public String getCatatan() { return catatan; }
    public double getJumlah() { return jumlah; }
    public boolean isPengeluaran() { return isPengeluaran; }
}
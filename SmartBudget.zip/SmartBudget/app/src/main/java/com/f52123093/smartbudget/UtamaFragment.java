package com.f52123093.smartbudget;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class UtamaFragment extends Fragment {

    private TextView txtTotal, txtPengeluaran, txtPenghasilan;
    private RecyclerView recyclerView;
    private TransaksiAdapter adapter;
    private DatabaseHelper dbHelper;
    private Button btnDetail;

    public UtamaFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_utama, container, false);

        txtTotal = v.findViewById(R.id.txtTotal);
        txtPengeluaran = v.findViewById(R.id.txtPengeluaran);
        txtPenghasilan = v.findViewById(R.id.txtPenghasilan);
        recyclerView = v.findViewById(R.id.recyclerTransaksi);
        btnDetail = v.findViewById(R.id.btnDetail);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        dbHelper = new DatabaseHelper(getContext());

        // button detail
        btnDetail.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), TransaksiDetailActivity.class);
            startActivity(intent);
        });

        // ke pengeluaran
        v.findViewById(R.id.btnTambah).setOnClickListener(view -> {
            MainActivity activity = (MainActivity) getActivity();
            if (activity != null && activity.getViewPager() != null) {
                activity.getViewPager().setCurrentItem(2);
            }
        });

        btnDetail.setOnClickListener(view -> {
            // ke transaksi detail
            Intent intent = new Intent(getActivity(), TransaksiDetailActivity.class);
            startActivity(intent);
        });

        tampilkanData();
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        tampilkanData();
    }

    private void tampilkanData() {
        ArrayList<TransaksiModel> daftarTransaksi = dbHelper.getSemuaTransaksi();

        // recyclerView
        adapter = new TransaksiAdapter(daftarTransaksi);
        recyclerView.setAdapter(adapter);

        // hitung total penghasilan dan pengeluaran
        double totalPenghasilan = 0;
        double totalPengeluaran = 0;

        for (TransaksiModel transaksi : daftarTransaksi) {
            if (transaksi.isPengeluaran()) {
                totalPengeluaran += transaksi.getJumlah();
            } else {
                totalPenghasilan += transaksi.getJumlah();
            }
        }

        // hitung saldo akhir
        double totalSaldo = totalPenghasilan - totalPengeluaran;
        DecimalFormat df = new DecimalFormat("#,###");

        txtTotal.setText("Rp" + df.format(totalSaldo));
        txtPenghasilan.setText("Rp" + df.format(totalPenghasilan));
        txtPengeluaran.setText("Rp" + df.format(totalPengeluaran));
    }
}

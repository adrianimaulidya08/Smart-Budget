    package com.f52123093.smartbudget;

    import android.content.Intent;
    import android.os.Bundle;
    import android.widget.TextView;

    import androidx.appcompat.app.AppCompatActivity;
    import androidx.fragment.app.Fragment;
    import androidx.viewpager.widget.ViewPager;
    import com.google.android.material.tabs.TabLayout;

    public class MainActivity extends AppCompatActivity {
        private TabLayout tabLayout;
        private ViewPager viewPager;

        private TextView tvWelcomeUser;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            tabLayout = findViewById(R.id.tab_layout);
            viewPager = findViewById(R.id.view_pager);

            tvWelcomeUser = findViewById(R.id.tv_welcome_user);

            Intent intent = getIntent();
            String username = intent.getStringExtra("USERNAME_KEY");

            if (username != null && !username.isEmpty()) {
                tvWelcomeUser.setText("Hi, " + username + "!");
            }

            setupViewPager();
        }

        private void setupViewPager() {
            ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
            adapter.addFragment(new UtamaFragment(), "Utama");
            adapter.addFragment(new IncomeFragment(), "Penghasilan");
            adapter.addFragment(new ExpenseFragment(), "Pengeluaran");

            viewPager.setAdapter(adapter);
            tabLayout.setupWithViewPager(viewPager);
        }
        public ViewPager getViewPager() {
            return viewPager;
        }
    }

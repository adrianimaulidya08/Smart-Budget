//package com.f52123093.smartbudget;
//
//import java.util.ArrayList;
//
//public class DataManager {
//    private static final ArrayList<TransaksiModel> daftarTransaksi = new ArrayList<>();
//
//    public static void tambahTransaksi(TransaksiModel transaksi) {
//        daftarTransaksi.add(transaksi);
//    }
//
//    public static ArrayList<TransaksiModel> getDaftarTransaksi() {
//        return daftarTransaksi;
//    }
//
//    public static double getTotalPengeluaran() {
//        double total = 0;
//        for (TransaksiModel t : daftarTransaksi) {
//            if (t.isPengeluaran()) total += t.getJumlah();
//        }
//        return total;
//    }
//
//    public static double getTotalPenghasilan() {
//        double total = 0;
//        for (TransaksiModel t : daftarTransaksi) {
//            if (!t.isPengeluaran()) total += t.getJumlah();
//        }
//        return total;
//    }
//}
//

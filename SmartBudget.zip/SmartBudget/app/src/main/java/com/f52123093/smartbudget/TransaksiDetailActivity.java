package com.f52123093.smartbudget;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TransaksiDetailActivity extends AppCompatActivity {

    private RecyclerView rvTransactions;
    private TransaksiAdapter adapter;
    private ArrayList<TransaksiModel> list;
    private DatabaseHelper dbHelper;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaksi_detail);

        toolbar = findViewById(R.id.toolbar_detail);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Semua Transaksi");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        rvTransactions = findViewById(R.id.rv_transaction_detail);
        rvTransactions.setHasFixedSize(true);

        dbHelper = new DatabaseHelper(this);
        list = dbHelper.getSemuaTransaksi(); // ambil data

        adapter = new TransaksiAdapter(list);

        rvTransactions.setLayoutManager(new LinearLayoutManager(this));
        rvTransactions.setAdapter(adapter);
    }

    // titik3
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_list) {
            rvTransactions.setLayoutManager(new LinearLayoutManager(this));
            return true;
        } else if (itemId == R.id.action_grid) {
            rvTransactions.setLayoutManager(new GridLayoutManager(this, 2));
            return true;
        } else if (itemId == android.R.id.home) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

package com.f52123093.smartbudget;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class TransaksiAdapter extends RecyclerView.Adapter<TransaksiAdapter.ViewHolder> {

    private ArrayList<TransaksiModel> transaksiList;


    private HashMap<String, Integer> iconMap;

    public TransaksiAdapter(ArrayList<TransaksiModel> transaksiList) {
        this.transaksiList = transaksiList;

        // Inisialisasi map icon
        iconMap = new HashMap<>();
        iconMap.put("Makanan", R.drawable.img1);
        iconMap.put("Kendaraan", R.drawable.img2);
        iconMap.put("Lainnya", R.drawable.img13);
        iconMap.put("Uang Saku", R.drawable.img3);
        iconMap.put("Freelance", R.drawable.img4);
        iconMap.put("Investasi", R.drawable.img12);
        // Tambahkan kategori lain jika ada
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaksi, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TransaksiModel transaksi = transaksiList.get(position);
        DecimalFormat df = new DecimalFormat("#,###");

        holder.txtKategori.setText(transaksi.getKategori());
        holder.txtCatatan.setText(transaksi.getCatatan()); // Ditambahkan
        holder.txtJumlah.setText("Rp" + df.format(transaksi.getJumlah()));

        // set icon dgn kategori
        Integer iconRes = iconMap.get(transaksi.getKategori());
        if (iconRes != null) {
            holder.imgIcon.setImageResource(iconRes);
        } else {
            holder.imgIcon.setImageResource(R.drawable.ic_launcher_background);
        }

        if (transaksi.isPengeluaran()) {
            holder.txtJumlah.setTextColor(holder.itemView.getContext()
                    .getResources().getColor(android.R.color.holo_red_dark));
        } else {
            holder.txtJumlah.setTextColor(holder.itemView.getContext()
                    .getResources().getColor(android.R.color.holo_green_dark));
        }
    }

    @Override
    public int getItemCount() {
        return transaksiList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtKategori, txtJumlah, txtCatatan;
        ImageView imgIcon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtKategori = itemView.findViewById(R.id.txtKategori);
            txtJumlah = itemView.findViewById(R.id.txtJumlah);
            txtCatatan = itemView.findViewById(R.id.txtCatatan);
            imgIcon = itemView.findViewById(R.id.img_item_photo);
        }
    }
}
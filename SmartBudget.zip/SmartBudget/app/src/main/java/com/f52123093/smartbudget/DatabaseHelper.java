package com.f52123093.smartbudget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "smartbudget.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_TRANSAKSI = "transaksi";

    private static final String TABLE_USER = "registeruser";
    private static final String COL_ID = "ID";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_TRANSAKSI + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "kategori TEXT, " +
                "catatan TEXT, " +
                "jumlah REAL, " +
                "tipe TEXT)";
        db.execSQL(createTable);

        String createTableUser = "CREATE TABLE " + TABLE_USER + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createTableUser);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            String createTableUser = "CREATE TABLE " + TABLE_USER + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_USERNAME + " TEXT, " +
                    COL_PASSWORD + " TEXT)";
            db.execSQL(createTableUser);
        } else {

            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSAKSI);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
            onCreate(db);
        }
    }

    public void tambahTransaksi(String kategori, String catatan, double jumlah, String tipe) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("kategori", kategori);
        values.put("catatan", catatan);
        values.put("jumlah", jumlah);
        values.put("tipe", tipe);
        db.insert(TABLE_TRANSAKSI, null, values);
        db.close();
    }


    public ArrayList<TransaksiModel> getSemuaTransaksi() {
        ArrayList<TransaksiModel> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_TRANSAKSI + " ORDER BY id DESC", null);

        if (cursor.moveToFirst()) {
            do {
                String kategori = cursor.getString(cursor.getColumnIndexOrThrow("kategori"));
                String catatan = cursor.getString(cursor.getColumnIndexOrThrow("catatan"));
                double jumlah = cursor.getDouble(cursor.getColumnIndexOrThrow("jumlah"));
                String tipe = cursor.getString(cursor.getColumnIndexOrThrow("tipe"));
                boolean isPengeluaran = tipe.equals("pengeluaran");

                list.add(new TransaksiModel(kategori, catatan, jumlah, isPengeluaran));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USER, null, contentValues);
        db.close();
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COL_ID};
        String selection = COL_USERNAME + " = ?" + " AND " + COL_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USER, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }
}